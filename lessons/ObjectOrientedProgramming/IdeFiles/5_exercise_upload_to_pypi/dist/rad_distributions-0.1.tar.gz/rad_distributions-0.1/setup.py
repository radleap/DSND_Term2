from setuptools import setup

setup(name='rad_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['rad_distributions'],
      author = 'Radleap',
      email = 'guy@radleap.com',
      zip_safe=False)
